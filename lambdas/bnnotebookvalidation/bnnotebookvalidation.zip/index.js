// index.ts
var PROCESS_BN_NOTEBOOK_VALIDATION_MUTATION = `
  mutation ProcessBudgetNeutralityNotebookValidation($documentId: ID!) {
    processBudgetNeutralityNotebookValidation(documentId: $documentId)
  }
`;
var graphqlEndpoint = process.env.GRAPHQL_ENDPOINT;
var graphqlAuthToken = process.env.GRAPHQL_AUTH_TOKEN;
function parseQueueMessage(body) {
  const parsed = JSON.parse(body);
  if (!parsed.documentId || typeof parsed.documentId !== "string") {
    throw new Error("Queue message is missing required 'documentId' string.");
  }
  return parsed;
}
async function processBudgetNeutralityNotebookValidation(documentId) {
  if (!graphqlEndpoint) {
    throw new Error("GRAPHQL_ENDPOINT environment variable is required.");
  }
  const response = await fetch(graphqlEndpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...graphqlAuthToken ? { Authorization: `Bearer ${graphqlAuthToken}` } : {}
    },
    body: JSON.stringify({
      query: PROCESS_BN_NOTEBOOK_VALIDATION_MUTATION,
      variables: {
        documentId
      }
    })
  });
  const payload = await response.json();
  if (!response.ok) {
    throw new Error(`BN Notebook validation request failed with status ${response.status}.`);
  }
  if (payload.errors?.length > 0) {
    throw new Error(`BN Notebook validation mutation failed: ${payload.errors[0].message}`);
  }
  if (!payload.data?.processBudgetNeutralityNotebookValidation) {
    throw new Error(`BN Notebook validation mutation returned false for document ${documentId}.`);
  }
}
var handler = async (event, context) => {
  console.info("Processing BN notebook validation event", {
    requestId: context.awsRequestId,
    records: event.Records.length
  });
  const results = {
    processedRecords: 0
  };
  for (const record of event.Records) {
    const message = parseQueueMessage(record.body);
    await processBudgetNeutralityNotebookValidation(message.documentId);
    console.info("Processed BN notebook validation request.", { documentId: message.documentId });
    results.processedRecords++;
  }
  console.info("All records processed successfully.", { results });
  return {
    statusCode: 200,
    body: `Processed ${results.processedRecords} records.`
  };
};
export {
  handler,
  parseQueueMessage,
  processBudgetNeutralityNotebookValidation
};
//# sourceMappingURL=index.js.map
